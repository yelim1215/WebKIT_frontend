# @babel/plugin-transform-classes

> Compile ES2015 classes to ES5

See our website [@babel/plugin-transform-classes](https://babeljs.io/docs/en/babel-plugin-transform-classes) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-classes
```

or using yarn:

```sh
yarn add @babel/plugin-transform-classes --dev
```
